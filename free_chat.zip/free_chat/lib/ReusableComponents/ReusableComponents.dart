import 'package:flutter/material.dart';

//*********** FOR ALL THE DEFAULT BUTTONS ****************
class BasicTextButton extends StatelessWidget {
  final String text;
  final Function onpressed;
 BasicTextButton({@required this.text, @required this.onpressed});
  @override
  Widget build(BuildContext context) {
    return RaisedButton(
      onPressed: onpressed,
      color: Colors.blue,
      elevation: 10.0,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(
          text,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            letterSpacing: 2.0,
          ),
        ),
      ),
    );
  }
}
//******************** FOR TEXT FIELDS **************
class TextFieldForm extends StatelessWidget {
  final String text;
  final bool obscureText;
  final Function onChanged;
  TextFieldForm({@required this.text,this.obscureText: false,this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        onChanged: onChanged,
        obscureText: obscureText,
        keyboardType: TextInputType.emailAddress,
        textAlign: TextAlign.center,
        decoration: InputDecoration(
          border: OutlineInputBorder(),
          labelText: text,
        ),
      ),
    );
  }
}
