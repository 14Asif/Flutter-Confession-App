import 'package:flutter/material.dart';

const TextStyle kAppBarTextStyle = TextStyle(
  fontWeight: FontWeight.bold,
);

const String kDarkPrimaryColor = '#0xFF1976D2';
const String kLightPrimaryColor = '#0xFFBBDEFB';
const String kAccentColor = '#0xFF03A9F4';
const String kPrimaryTextColor = '#0xFF212121';
const String kSecondaryTextColor = '#0xFF757575';
const String kDividerColor = '#0xFFBDBDBD';




