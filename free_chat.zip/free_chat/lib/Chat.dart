import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
class ChatScreen extends StatefulWidget {
  static String id = 'chat_screen';
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
//  final _auth = FirebaseAuth.instance;
//  FirebaseUser loggedInUser;
//
//  void getCurrentUser() async{
//    try{
//      final user = await _auth.currentUser();
//      if(user != null){
//        loggedInUser = user;
//        print(loggedInUser.email);
//      }
//    }
//    catch(e){
//      print(e);
//    }
//  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FreeChat 4 ALL'),
      ),
      body: Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(
          children: <Widget>[
            Text('hello world chat screen here!'),
          ],
        ),
      ),
    );
  }
}
