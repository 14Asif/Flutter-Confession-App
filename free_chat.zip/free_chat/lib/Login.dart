import 'package:flutter/material.dart';
import 'package:free_chat/ReusableComponents/constants.dart';
import 'package:free_chat/ReusableComponents/ReusableComponents.dart';
import 'package:free_chat/Chat.dart';

class LoginScreen extends StatefulWidget {
  static String id = 'login_screen';
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'LOG IN',
          style: kAppBarTextStyle,
        ),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Image(image: AssetImage('assets/Images/login.png')),
          ),
          Expanded(
            child: Column(
              children: <Widget>[
                TextFieldForm(text: 'USERNAME'),
                TextFieldForm(text: 'PASSWORD',obscureText: true,),
                SizedBox(
                  height: 20.0,
                ),
                BasicTextButton(
                    text: 'LOG IN',
                    onpressed: () {
                      Navigator.pushNamed(context, ChatScreen.id);
                    })
              ],
            ),
          ),
        ],
      ),
    );
  }
}
