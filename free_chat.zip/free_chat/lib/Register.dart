import 'package:flutter/material.dart';
import 'package:free_chat/Chat.dart';
import 'package:free_chat/ReusableComponents/constants.dart';
import 'package:free_chat/ReusableComponents/ReusableComponents.dart';
import 'package:firebase_auth/firebase_auth.dart';


class RegisterScreen extends StatefulWidget {
  static String id = 'register_screen';
  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  String email,password;
  final _auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'REGISTER',
          style: kAppBarTextStyle,
        ),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
                child: Image(image: AssetImage('assets/Images/register.png')),
              height: 50.0,
            ),
          ),
          Expanded(
            flex: 2,
            child: ListView(
              children: <Widget>[
                TextFieldForm(text: 'EMAIL ID',onChanged: (value){
                  email = value;
                },),
                SizedBox(height: 8.0),
                TextFieldForm(text: 'PASSWORD',obscureText: true,onChanged: (value){
                  password = value;
                }),
                SizedBox(height: 8.0),
                TextFieldForm(text: 'USERNAME'),
                SizedBox(height: 10.0),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: BasicTextButton(
                      text: 'SIGN UP',
                      onpressed: () async{
                        try {
                          final newUser = await _auth.createUserWithEmailAndPassword(
                              email: email, password: password);
                          if(newUser != null){
                            Navigator.pushNamed(context, ChatScreen.id);
                          }
                        }
                        catch(e){
                          print(e);
                        }
                      }),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
